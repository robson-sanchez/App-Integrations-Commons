export default ({
  app_title: 'Configure JIRA',
  app_name: 'JIRA',
  IM_shorthand: 'JIRA', // will display "One on One with JIRA"
  toogleSetupInstructions: true,
  logo: 'jira_logo.png',
});
