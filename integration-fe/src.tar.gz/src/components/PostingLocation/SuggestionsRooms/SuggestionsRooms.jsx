/* eslint-disable react/no-unused-prop-types */
/* eslint-disable no-debugger */
/* eslint-disable no-unused-vars */
/* eslint-disable no-console */
import React, { PropTypes, Component } from 'react';
import './styles/styles.less';

class SuggestionsRooms extends Component {
  constructor(props) {
    super(props);

    this.state = {
      filters: [],
      filteredRooms: [],
      listening: false, // check if input search has event listener
      focused: -1,
    };
    this.container = null;
    this.input = null;
    this.list = null;
    this.onChangeSearch = this.onChangeSearch.bind(this);
    this.inputListener = this.inputListener.bind(this);
    this.addInputListener = this.addInputListener.bind(this);
    this.removeInputListener = this.removeInputListener.bind(this);
    this.clearInput = this.clearInput.bind(this);
  }

  componentWillMount() {
    if (this.props.userRooms.length === 0) {
      this.props.fetchUserRooms();
    }
  }

  componentDidMount() {
    console.error(`nextProps ${this.props.loading}`);
    const tmr = setInterval(() => {
      if (!this.props.loading) {
        clearInterval(tmr);
        console.error(`nextProps ${this.props.loading}`);
        this.input.focus();
      }
    }, 500);
  }

  onChangeSearch(e) {
    const target = e.target;
    if (target.value === '') {
      this.setState({
        filteredRooms: [],
      });
      return;
    }
    let suggestionsList = this.props.userRooms.slice();
    suggestionsList = suggestionsList.filter(item =>
      item.name.toLowerCase().search(e.target.value.toLowerCase()) !== -1
    );
    if (target.value !== '') {
      if (!this.state.listening) {
        this.addInputListener();
      }
    } else if (target.value === '') {
      if (this.state.listening) {
        this.removeInputListener();
      }
    }
    this.setState({
      filteredRooms: suggestionsList,
    });
  }

  inputListener(event) {
    let idx = this.state.focused;
    const key = event.keyCode;
    if ((idx === -1 && key === 38) || (idx > this.state.filteredRooms.length - 1 && key === 40)) {
      setTimeout(() => {
        this.input.value = this.input.value;
        this.input.focus();
      }, 10);
      return;
    } else if (idx === -1 && key === 40) {
      this.input.blur();
      this.removeInputListener();
      this.list.addEventListener('keydown', this.inputListener);
    } else if (idx === 0 && key === 38) {
      // setInterval put the cursor after the input value...
      const tmr = setInterval(() => {
        if (this.input.value !== '') {
          clearInterval(tmr);
          this.input.focus();
        }
      }, 50);
      this.list.removeEventListener('keydown', this.inputListener);
      this.addInputListener();
    }
    if (this.state.filteredRooms.length > 0 && this.state.filteredRooms.length > idx) {
      if (key === 40) { // arrow down
        idx += 1;
      } else if (key === 38) { // arrow up
        idx -= 1;
      }
      if (idx > -1) {
        this.list.childNodes[idx].childNodes[0].focus();
      }
    }
    this.setState({
      focused: idx,
    });
  }

  addInputListener() {
    this.input.addEventListener('keydown', this.inputListener);
    this.setState({
      listening: true,
    });
  }

  removeInputListener() {
    this.input.removeEventListener('keydown', this.inputListener);
    this.setState({
      listening: false,
    });
  }

  clearInput() {
    this.setState({
      filteredRooms: [],
      focused: -1,
    });
    this.input.value = '';
    this.input.focus();
  }

  render() {
    return (
      <div className='suggestions-rooms'>
        <span>{`focused: ${this.state.focused}`}</span>
        <div className='input-search-container'>
          <input
            type='text'
            onChange={this.onChangeSearch}
            ref={(input) => { this.input = input; }}
            placeholder={this.props.loading ? 'Loading...' : 'Search rooms'}
          />
          <button onClick={this.clearInput}>
            <i className='fa fa-times' />
          </button>
        </div>
        <ul
          className='filter-container'
          ref={(list) => { this.list = list; }}
        >
          {
            this.state.filteredRooms.map((filter, idx) =>
              <li className='filter-box' key={idx}>
                <a
                  href='#'
                  className='filter-box-clickable'
                >
                  <div>
                    <span>{filter.name}</span>
                    { !filter.publicRoom && (<span><i className="fa fa-lock" /></span>)}
                  </div>
                  <div className='room-info'>
                    <span>
                      {
                        `${filter.memberCount} Member${filter.memberCount > 1 ? 's' : ''},
                         created by ${filter.creatorPrettyName}`
                      }
                    </span>
                  </div>
                </a>
              </li>
            )
          }
        </ul>
      </div>
    );
  }
}

SuggestionsRooms.propTypes = {
  fetchUserRooms: PropTypes.func.isRequired,
  userRooms: PropTypes.arrayOf(PropTypes.object).isRequired,
  loading: PropTypes.bool.isRequired,
};

export default SuggestionsRooms;
